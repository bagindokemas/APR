#make dictionary for NELL relation

x = open("Mate2BigData/Iteration1/specialPBR/DBPediaRelationDict.txt","w")

with open('Data/ListofRelations.txt') as a:
	seenRel=set()
	#i dimulai dari  38674 karena Dictionary Instance maximalnya  38674
	i=93863
	for line in a:
		row=line.split()
		if(row[0] not in seenRel):
			seenRel.add(row[0])
			x.write(row[0]+"\t"+str(i)+"\n")		
			i += 1
		
x.close()
