#script untuk convert data dbpedia ke integer

a = open("Mate2BigData/Iteration1/specialPBR/InputIte2WD.txt")
b = open("Mate2BigData/Iteration1/specialPBR/DBPediaInstanceDictionary.txt")
c = open("Mate2BigData/Iteration1/specialPBR/DBPediaRelationDict.txt")
x = open("Mate2BigData/Iteration1/specialPBR/_DBPediainInteger.txt","w")

#make dictionary
InstanceDict = {}
for lineB in b:
	rowB = lineB.split()
	#kolom 1 adalah string Instance DBPedia 
	#kolom 2 adalah integer
	k1 = rowB[0] 
	v1 = rowB[1]
	InstanceDict[k1]=v1

RelationDict = {}
for lineC in c:
	rowC = lineC.split()
	#kolom 1 adalah string relation DBPedia 
	#kolom 2 adalah integer
	k2 = rowC[0] 
	v2 = rowC[1]
	RelationDict[k2]=v2

for lineA in a:
        cHead = 0
        cRel = 0
        cTail = 0
	rowA = lineA.split()
	if(rowA[0] in InstanceDict):
		head = InstanceDict[rowA[0]]		
		cHead+=1
	if(rowA[1] in RelationDict):
		rel = RelationDict[rowA[1]]
		cRel+=1
	if(rowA[2] in InstanceDict):
		tail = InstanceDict[rowA[2]]
		cTail+=1
	if(cHead+cRel+cTail==3):
		x.write(head+"\t"+rel+"\t"+tail+"\n")
		
x.close()
		
	
