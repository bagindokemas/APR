a = open("Mate2BigData/Iteration1/specialPBR/NotValid.txt")
b = open("Mate2BigData/Iteration1/specialPBR/NotValidWD.txt","w")

seen = set()
for line in a:
	if line not in seen:
		seen.add(line)
		b.write(line)

b.close()
