from sets import Set

ori_all = set(open("Mate2BigData/Iteration1/specialPBR/_DBPediainInteger.txt"))
invalid = set(open("Mate2BigData/Iteration1/specialPBR/NotValidWD.txt"))
unknownWO = set(open("Mate2BigData/Iteration1/specialPBR/unknownWO.txt"))

c = open("Mate2BigData/Iteration1/specialPBR/validTriples.txt","w")

validTriple = ori_all-invalid-unknownWO

for line in validTriple :
	c.write(line)

c.close()


