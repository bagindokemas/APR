from sets import Set

unknownWD = set(open("Mate2BigData/Iteration1/specialPBR/UnknownWD.txt"))
overlap = set(open("Mate2BigData/Iteration1/specialPBR/OverlapTripleTemp.txt"))

c = open("Mate2BigData/Iteration1/specialPBR/unknownWO.txt","w")

unknownWithoutOverlap = unknownWD-overlap 

for line in unknownWithoutOverlap:
	c.write(line)

c.close()


