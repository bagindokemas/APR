a=open("Mate2BigData/Iteration1/specialPBR/NotValidWD.txt")
b=open("Mate2BigData/Iteration1/specialPBR/UnknownWD.txt")

c = open("Mate2BigData/Iteration1/specialPBR/OverlapTripleTemp.txt","w")

dictB = {}
for i2,line2 in enumerate(b):
	k2 = line2
	v2 = i2
	dictB[k2]=v2

for lineA in a:
	if lineA in dictB:
		c.write(lineA)

c.close()
