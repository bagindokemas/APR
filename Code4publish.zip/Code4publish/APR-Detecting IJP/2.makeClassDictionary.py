#make dictionary for DBPedia classes

x = open("Mate2BigData/Iteration1/specialPBR/DBPediaClassDict.txt","w")

with open('Data/ListofClasses.txt') as a:
	seenClass=set()
	#i dimulai dari 39816 karena Dictionary relation maximalnya 39816
	i=95005
	for line in a:
		row=line.split()
		if(row[0] not in seenClass):
			seenClass.add(row[0])
			x.write(row[0]+"\t"+str(i)+"\n")		
			i += 1
		
x.close()
