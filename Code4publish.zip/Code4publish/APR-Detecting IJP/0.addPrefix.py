#script for adding predicate resource/ontology to the triple

a = open("Mate1BigData/2ndPBR/KB2EOutput.txt")
b = open("Mate1BigData/2ndPBR/forPBR.txt","w")

for line in a:
	row = line.split()
	b.write("http://dbpedia.org/resource/"+row[0]+"\t"+"http://dbpedia.org/ontology/"+row[1]+"\t"+"http://dbpedia.org/resource/"+row[2]+"\n")

b.close()
